<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
  public function random_user() {
		$user = User::inRandomOrder()->first();

		return [
			'id' => $user->id
		];
	}
}
